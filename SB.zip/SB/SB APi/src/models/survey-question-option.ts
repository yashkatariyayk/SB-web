export class SurveyQuestionOption {
    SurveyQuestionOptionId: number;
    SurveyId: number;
    SurveyQuestionId: number;
    Name: string;
    ControlTypeId: number;
    SortOrder: number;
    IsComment: boolean;
    IsCommentRequire: boolean;
}