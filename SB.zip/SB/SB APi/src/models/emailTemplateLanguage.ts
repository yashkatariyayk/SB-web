export class EmailTemplateLanguage {
  EmailTemplateLanguageId: number;
  EmailTemplateId: number;
  LanguageId: number;
  Subject: string;
  Body: string;
}
