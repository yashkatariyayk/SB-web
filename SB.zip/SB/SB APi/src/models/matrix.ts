export class MatrixType {
    MatrixTypeId: number;
    Name: string;
}