export class SurveyQuestionLanguage {
  SurveyQuestionLanguageId: number;
  SurveyQuestionId: number;
  SurveyId: number;
  SurveyPageId: number;
  Name: string;
  Description: string;
  LanguageId: number;
}
