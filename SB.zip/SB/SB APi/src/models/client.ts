export class Client {
    ClientId: number;
    Name: string;
    Logo: string;
    Email: string;
    IsDeleted: boolean;
    CreatedDate: string;
}