export class SurveyQuestionOptionLanguage {
  SurveyQuestionOptionLanguageId: number;
  SurveyQuestionOptionId: number;
  SurveyId: number;
  SurveyQuestionId: number;
  Name: string;
  LanguageId: number;
}
