export class EmailTemplate {
    EmailTemplateId: number;
    Title: string;
    Subject: string;
    Body: string;
    Email: string;
    FirstName: string;
    SurveyName: string;
    SurveySelectorId: number;
}