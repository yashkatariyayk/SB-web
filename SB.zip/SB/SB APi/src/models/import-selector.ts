export class ImportSelector {
    Id: number;
    SurveyId: number;
    LastImportedDate: string;
}