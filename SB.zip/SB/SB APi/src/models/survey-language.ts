export class SurveyLanguage {
  SurveyLanguageId: number;
  SurveyId: number;
  Name: string;
  LanguageId: string;
}
