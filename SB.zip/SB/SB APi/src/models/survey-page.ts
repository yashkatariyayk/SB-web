export class SurveyPage {
    SurveyPageId: number;
    SurveyId: number;
    Name: string;
    Description: string;
    PageOrder: number;
    SurveyPageTypeId: number;
    IsDeleted: boolean;
}