// ng build --configuration=dev --base-href /EEPulseSurveyBuilder/Web/
export const environment = {
  production: false,
  RootUrl: "http://203.192.235.219:9090/EEPulseSurveyBuilder/Web/",
  SurveyUrl: "http://203.192.235.219:9090/EEPulseSurvey/Web/",
  APIURL: "http://203.192.235.219:9090/EEPulseSurveyBuilder/Api/api",
  IMAGEURL: "http://203.192.235.219:9090/EEPulseSurveyBuilder/Api/static/",
  whitelistedDomains: ["203.192.235.219:9090", "ta33"],
  blacklistedRoutes: []
};

