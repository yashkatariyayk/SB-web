import { NgModule } from '@angular/core';
import { DashboardLayoutComponent } from './dashboard-layout/dashboard-layout.component';
import { HeaderComponent } from './header/header.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { AppRoutingModule } from '../app-routing.module';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';
import { Ng7MatBreadcrumbModule } from 'ng7-mat-breadcrumb';
import { ToasterModule } from 'angular2-toaster';
@NgModule({
  declarations: [
    DashboardLayoutComponent,
    HeaderComponent,
    SidebarComponent,
  ],
  imports: [
    AppRoutingModule,
    CommonModule,
    SharedModule,
    ToasterModule,
    Ng7MatBreadcrumbModule,
  ],
  providers: [],
})
export class LayoutModule { }
