import { Component, OnDestroy, AfterViewInit } from "@angular/core";
import {
  Router,
  NavigationStart,
  NavigationEnd,
  NavigationCancel
} from "@angular/router";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.scss"]
})
export class AppComponent implements OnDestroy, AfterViewInit {
  private sub: any;

  constructor(private router: Router) {}

  ngAfterViewInit() {
    this.router.events.subscribe(
      event => {
        if (event instanceof NavigationStart) {
          // preview page handle body scroll
          const body = document.getElementsByTagName("body")[0];
          if (event.url.match("/preview/")) {
            body.classList.add("preview-body");
          } else {
            body.classList.remove("preview-body");
          }
          // Show Loader
        } else if (
          event instanceof NavigationEnd ||
          event instanceof NavigationCancel
        ) {
          // Hide loader
        }
      },
      (error: any) => {
        // Hide loader
      }
    );
  }

  ngOnDestroy(): any {
    this.sub.unsubscribe();
  }
}
