import { Injectable } from "@angular/core";
import { environment } from "src/environments/environment";

@Injectable()
export class RouteConfig {
  url(url): string {
    return environment.APIURL.toString() + url;
  }
}
