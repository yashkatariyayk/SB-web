import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeMatrixMultiChoiseComponent } from './employee-matrix-multi-choise.component';

describe('EmployeeMatrixMultiChoiseComponent', () => {
  let component: EmployeeMatrixMultiChoiseComponent;
  let fixture: ComponentFixture<EmployeeMatrixMultiChoiseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeeMatrixMultiChoiseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeMatrixMultiChoiseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
