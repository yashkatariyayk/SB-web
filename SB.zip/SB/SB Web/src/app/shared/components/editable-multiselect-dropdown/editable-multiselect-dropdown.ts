export class SelecteeFilter {
  FirstName: string;
  LastName: string;
  Email: string;
  Department: string;
  Role: string;
  Miscellaneous: string;
  skip: number;
  limit: number;
}

export class AddSelectee {
  FirstName: string;
  LastName: string;
  Email: string;
  Name: string;
}
