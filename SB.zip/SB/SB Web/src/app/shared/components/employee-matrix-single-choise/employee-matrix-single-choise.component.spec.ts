import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeMatrixSingleChoiseComponent } from './employee-matrix-single-choise.component';

describe('EmployeeMatrixSingleChoiseComponent', () => {
  let component: EmployeeMatrixSingleChoiseComponent;
  let fixture: ComponentFixture<EmployeeMatrixSingleChoiseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeeMatrixSingleChoiseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeMatrixSingleChoiseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
