export class Question {
    Id: number;
    QuestionText: string;
    ScaleId: number;
    ScaleTypeId: number;
    value: Array<any> = [];
    IsEdit: boolean;
}

export class SurveyQuestion {
    SurveyQuestionId: number;
    SurveyId: number;
    SurveyPageId: number;
    Name: string;
    Description: string;
    SortOrder: number;
    ScaleTypeId: number;
    MatrixTypeId: number;
    IsRequire: boolean;
    IsMaxChoice: boolean;
    MaxChoice: number;
    IsOther: boolean;
    IsEdit: boolean;
    IsDeleted: boolean;
    ParentQuestionId: number;
    LanguageId: number;
    SurveyQuestionLanguageId: number;
    ChildQuestion: SurveyQuestion[];
}

export class SurveyQuestionOption {
    SurveyQuestionOptionId: number;
    SurveyId: number;
    SurveyQuestionId: number;
    Name: string;
    ControlTypeId: number;
    SortOrder: number;
    IsComment: boolean;
    IsCommentRequire: boolean;
    LanguageId: number;
    SurveyQuestionOptionLanguageId: number;
    value: string;
}

export class SurveyQuestionOptionVM {
    Question: SurveyQuestion[];
    Option: SurveyQuestionOption[];
}

export class SurveyQuestionScaleType {
    SurveyQuestionScaleTypeId: number;
    Name: string;
    SortOrder: number;
}

export class MatrixType {
    MatrixTypeId: number;
    Name: string;
}

export class SurveyQuestionScaleBank {
    SurveyQuestionScaleBankId: number;
    Name: string;
    UserId: number;
    SurveyQuestionControlTypeId: number;
    Value: SurveyQuestionScaleBankValue[] = [];
}

export class SurveyQuestionScaleBankValue {
    SurveyQuestionScaleBankValueId: number;
    SurveyQuestionScaleBankId: number;
    Text: string;
    Value: string;
}