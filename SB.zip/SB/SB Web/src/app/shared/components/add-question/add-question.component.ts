import { Component, OnInit, Input, Output, EventEmitter, ElementRef, ViewChild, AfterContentChecked, ChangeDetectorRef } from '@angular/core';
import { SurveyQuestionScaleType, SurveyQuestionScaleBank, SurveyQuestion, SurveyQuestionOption, SurveyQuestionOptionVM, MatrixType } from './question.model';
import { MatDialog } from '@angular/material';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';
import { FormControl, Validators } from '@angular/forms';
import { AddQuestionService } from './add-question.service';
import { CommonService } from 'src/app/core/services/common.service';
import { SurveyDetailService } from 'src/app/pages/survey/survey-detail/survey-detail.service';

@Component({
  selector: 'app-add-question',
  templateUrl: './add-question.component.html',
  styleUrls: ['./add-question.component.css']
})
export class AddQuestionComponent implements OnInit, AfterContentChecked {
  @ViewChild('questionPanel', { read: ElementRef, static: false }) public questionPanel: ElementRef<any>;
  @Output() messageEvent = new EventEmitter<any>();
  @Output() removeQuestion = new EventEmitter<any>();
  @Output() addQuestion = new EventEmitter<any>();
  @Input() questionOrder: any;
  @Input() surveyPage: any;
  @Input() isLive: boolean;
  @Input() question: any;
  @Input() surveyId: number;
  @Input() matrixType: MatrixType[];
  @Input() surveyQuestionScaleType: SurveyQuestionScaleType[];
  @Input() questionScaleBank: SurveyQuestionScaleBank[];

  public showError: boolean = false;
  public isShowSubQuestionError: boolean = false;
  public copyQuestionScaleBank: SurveyQuestionScaleBank[];
  public filterSurveyQuestionScaleType: SurveyQuestionScaleType[] = [];
  public formInvalid: boolean = false;
  public isSurveyNameValid: boolean = false;
  public questionOptionCount: number;
  public subQuestionCount: number = 2;
  public questionTextFormControl = new FormControl('', [Validators.required]);
  public selectedScale: number = 1;
  public selectedMatrixType: number = 1;
  public showAdvance: boolean;
  public index: number = 1;
  public currentQuestionOrder: number;
  public filteredscaleTypeOption: any;
  public showOption: boolean;
  public commentvalue: string = '';
  public Text: string = 'Save';
  public surveyQuestion: SurveyQuestion;
  public questionOption: SurveyQuestionOption[] = [];
  public questionOptionVM: SurveyQuestionOptionVM;
  public loader: boolean;
  public value: number;
  public radioButtons = [{ id: 1, Text: '', SurveyQuestionId: 0, ParentQuestionId: 0 }];
  public copyRadioButtons: any[] = [];

  constructor(private elem: ElementRef,
    public dialog: MatDialog,
    private addQuestionService: AddQuestionService,
    private commonService: CommonService,
    private ref: ChangeDetectorRef
  ) { }

  ngOnInit() {
    this.currentQuestionOrder = this.questionOrder;
    this.surveyQuestion = new SurveyQuestion();
    this.surveyQuestion.ScaleTypeId = 1;
    this.surveyQuestion.MatrixTypeId = 1;
    this.questionOptionVM = new SurveyQuestionOptionVM();
    this.questionScaleBank ? this.copyQuestionScaleBank = JSON.parse(JSON.stringify(this.questionScaleBank)) : [];
    this.surveyQuestionScaleType ? this.filterSurveyQuestionScaleType = JSON.parse(JSON.stringify(this.surveyQuestionScaleType)) : [];
    this.questionOptionCount = this.questionOption.filter(t => t.Name.trim() !== '').length;
    this.copyRadioButtons = JSON.parse(JSON.stringify(this.radioButtons));
    //  setInterval(() => this.formValidCheck(), 500);
  }

  ngAfterContentChecked() {
    this.ref.detectChanges();
  }

  validateQuestionText() {
    this.questionTextFormControl.valid || this.questionTextFormControl.value !== null ? this.isSurveyNameValid = true : this.isSurveyNameValid = false;
  }

  formValidCheck() {
    let count = this.questionOption.filter(t => t.Name.trim() !== '').length;
    if (this.Text === 'Save') {
      count >= 2 ? this.showError = false : this.showError = true;
    }
    if (this.selectedMatrixType === 3) {
      this.getSubQuestionValues();
      if (this.showError || this.isShowSubQuestionError || !this.questionTextFormControl.valid) {
        this.formInvalid = true;
      } else {
        this.formInvalid = false;
      }
    } else {
      if (this.showError || !this.questionTextFormControl.valid) {
        this.formInvalid = true;
      } else {
        this.formInvalid = false;
      }
    }
  }

  getPageQuestion() {
    this.questionOrder = this.questionOrder;
    this.addQuestion.emit(this.questionOrder);
  }

  showAdvanceOptions() {
    this.showAdvance = this.showAdvance ? false : this.showAdvance;
  }

  getOptionsValues(event) {
    this.questionOption = JSON.parse(JSON.stringify(event));
    this.questionOptionCount = this.questionOption.filter(t => t.Name.trim() !== '').length;
    if (this.Text === 'Save') {
      this.questionOptionCount >= 2 ? this.showError = false : this.showError = true;
    }
  }

  bindTextInput(event) {
    this.selectedScale = event.value;
    if (this.selectedScale === 3 || this.selectedScale === 4 || (this.selectedScale === 5)) {
      this.questionOptionCount = 2;
    } else {
      this.questionOptionCount = 0;
    }
  }

  bindscaleValues(event) {
    let questionScaleBank = JSON.parse(JSON.stringify(this.questionScaleBank));
    this.filteredscaleTypeOption = questionScaleBank.find(t => t.SurveyQuestionScaleBankId === event.value).Value;
    if (this.filteredscaleTypeOption.length === 0) {
      this.copyQuestionScaleBank = JSON.parse(JSON.stringify(this.questionScaleBank));
      this.filteredscaleTypeOption = this.copyQuestionScaleBank.find(t => t.SurveyQuestionScaleBankId === event.value).Value;
    }
    //   this.showOption = true;
  }

  onQuestionDelete(questionId) {
    const dialogConfirmRef = this.dialog.open(ConfirmDialogComponent, {
      width: '350px',
    });
    dialogConfirmRef.componentInstance.message = 'You want to delete this question?';
    dialogConfirmRef.componentInstance.btnOkText = 'Yes';
    dialogConfirmRef.componentInstance.btnCancelText = 'No';

    dialogConfirmRef.afterClosed().subscribe(result => {
      if (result === true) {
        this.addQuestionService.removeQuestion(questionId).subscribe((res: any) => {
          if (res.Status == 'success') {
            this.commonService.toaster('Question deleted successfully.', true);
            this.removeQuestion.emit(this.questionOrder);
          } else {
            this.commonService.toaster(res.Message, false);
          }
        });
      }
    });
  }

  addUpdateQuestion(questionId) {
    this.loader = true;
    if (!this.questionTextFormControl.valid || this.questionTextFormControl.value.trim() === '') {
      this.loader = false;
      this.questionTextFormControl.setValue(null);
      return false;
    }
    if ((this.selectedScale === 1) || (this.selectedScale === 2) || (this.selectedScale === 6)) {
      if (this.questionOption.length > 0) {
        let count = this.questionOption.filter(t => t.Name.trim() !== '').length;
        if (count >= 2) {
          this.questionOption = this.questionOption.filter(t => t.Name.trim() !== '');
          this.showError = false;
        } else {
          this.loader = false;
          this.showError = true;
          return false;
        }
      } else {
        this.loader = false;
        this.showError = true;
        return false;
      }
    } else {
      this.showError = false;
    }
    if (this.selectedMatrixType === 3) {
      let isSubQuestionLength = this.radioButtons.filter(t => t.Text.trim() !== '').length;
      isSubQuestionLength < 1 ? this.isShowSubQuestionError = true : this.isShowSubQuestionError = false;
      if (this.isShowSubQuestionError === true) {
        this.loader = false;
        return false;
      }
    }
    this.questionOptionVM.Question = [];
    let questionObj = new SurveyQuestion();
    this.questionOptionVM.Option = [];
    questionObj.SurveyId = this.surveyPage.SurveyId;
    questionObj.SurveyPageId = this.surveyPage.SurveyPageId;
    questionObj.Name = this.surveyQuestion.Name.trim();
    questionObj.Description = this.surveyQuestion.Description;
    questionObj.ScaleTypeId = this.surveyQuestion.ScaleTypeId;
    questionObj.MatrixTypeId = this.surveyQuestion.MatrixTypeId;
    questionObj.IsRequire = this.surveyQuestion.IsRequire !== undefined ? this.surveyQuestion.IsRequire : false;
    if (this.Text === 'Save') {
      questionObj.SortOrder = this.questionOrder;
    } else {
      questionObj.SurveyQuestionId = questionId;
    }
    this.questionOptionVM.Question.push(questionObj);
    let multipleQuestion = this.radioButtons.filter(t => t.Text.trim() !== '');
    if (multipleQuestion.length > 0) {
      multipleQuestion.forEach(element => {
        if (element.Text) {
          let subQuestionObj = new SurveyQuestion();
          subQuestionObj.SurveyId = this.surveyPage.SurveyId;
          subQuestionObj.SurveyPageId = this.surveyPage.SurveyPageId;
          subQuestionObj.Name = element.Text;
          subQuestionObj.MatrixTypeId = this.surveyQuestion.MatrixTypeId;
          subQuestionObj.ParentQuestionId = 0;
          if (this.Text === 'Update') {
            subQuestionObj.SurveyQuestionId = element.SurveyQuestionId;
            subQuestionObj.ParentQuestionId = questionId;
          }
          //  questionObj.Description = this.surveyQuestion.Description;
          subQuestionObj.ScaleTypeId = this.surveyQuestion.ScaleTypeId;
          subQuestionObj.IsRequire = this.surveyQuestion.IsRequire !== undefined ? this.surveyQuestion.IsRequire : false;
          this.questionOptionVM.Question.push(subQuestionObj);
        }
      });
    }
    this.questionOption.forEach(element => {
      element.ControlTypeId = this.surveyQuestion.ScaleTypeId;
      element.SortOrder = 1;
      if (this.Text === 'Update') {
        element.SurveyQuestionId = questionId;
        element.SurveyId = this.surveyPage.SurveyId;
        element.value === "" ? element.SurveyQuestionOptionId = 0 : false;
      } else {
        element.SurveyQuestionOptionId = 0;
      }
    });
    if ((this.selectedScale === 1) || (this.selectedScale === 2) || (this.selectedScale === 6)) {
      this.questionOptionVM.Option = this.questionOption;
    }
    this.Text === 'Save' ? this.saveQuestion() : this.updateQuestion(questionId);
  }

  saveQuestion() {
    this.addQuestionService.saveQuestion(this.questionOptionVM).subscribe((res: any) => {
      if (res.Status == 'success') {
        if (res.Data !== null || res.Data !== undefined) {
          let qId: number;
          if (res.Data && res.Data[0]) {
            qId = res.Data[0].SurveyQuestionId;
          } else {
            qId = res.Data.SurveyQuestionId;
          }
          // qId = res.Data.SurveyQuestionId;
          this.getQuestionByQuestionId(qId);
          this.commonService.toaster('Question added successfully.', true);
          this.question.IsEdit = false;
          this.surveyQuestion.IsEdit = false;
          let obj = {
            SurveyId: this.surveyPage.SurveyId,
            SurveyPageId: this.surveyPage.SurveyPageId
          };
        } else {
          this.commonService.toaster(res.Message, false);
        }
      }
      this.loader = false;
      //   this.scrollToBottom();
    });
  }

  getQuestionByQuestionId(questionId) {
    this.addQuestionService.getQuestionByQuestionId(questionId).subscribe((res: any) => {
      if (res.Status == 'success') {
        if (res.Data.length > 0) {
          this.question = JSON.parse(JSON.stringify(res.Data[0]));
          this.surveyQuestion.IsRequire = this.question.IsRequire;
          this.question.ScaleTypeId = this.selectedScale;
          this.surveyQuestion.ScaleTypeId = this.selectedScale;
        }
      } else {
        this.commonService.toaster(res.Message, false);
      }
    });
  }

  updateQuestion(questionId) {
    this.addQuestionService.updateQuestion(this.questionOptionVM).subscribe((res: any) => {
      if (res.Status == 'success') {
        this.commonService.toaster('Question updated successfully.', true);
        this.question.IsEdit = false;
        this.surveyQuestion.IsEdit = false;
        let obj = {
          SurveyId: this.surveyPage.SurveyId,
          SurveyPageId: this.surveyPage.SurveyPageId
        };
        this.loader = false;
        this.getQuestionByQuestionId(questionId);
        //  this.addQuestion.emit(obj);
      } else {
        this.loader = false;
        this.commonService.toaster(res.Message, false);
      }
      //  this.scrollToBottom();
    });
  }

  clickOnEdit(question) {
    this.surveyQuestion = JSON.parse(JSON.stringify(question));
    this.selectedScale = question.ScaleTypeId;
    if (this.selectedScale === 3 || this.selectedScale === 4 || (this.selectedScale === 5)) {
      this.questionOptionCount = 2;
    }
    this.filteredscaleTypeOption = JSON.parse(JSON.stringify(question.SurveyQuestionOption));
    this.question.IsEdit = true;
    this.radioButtons = [];
    this.question.ChildQuestion.forEach(element => {
      let Obj = {
        id: this.radioButtons.length + 1,
        Text: element.Name.trim(),
        SurveyQuestionId: element.SurveyQuestionId,
        ParentQuestionId: element.ParentQuestionId
      };
      this.radioButtons.push(Obj);
    });
    this.selectedMatrixType = question.MatrixTypeId;
    if (this.selectedMatrixType === 2 || (this.selectedMatrixType === 3)) {
      this.filterSurveyQuestionScaleType = this.surveyQuestionScaleType.filter(t => t.SurveyQuestionScaleTypeId === 1 || t.SurveyQuestionScaleTypeId === 2);
    } else {
      this.filterSurveyQuestionScaleType = JSON.parse(JSON.stringify(this.surveyQuestionScaleType));
    }
    this.copyQuestionScaleBank = JSON.parse(JSON.stringify(this.questionScaleBank));
    this.Text = 'Update';
  }

  cancelQuestion(question) {
    this.Text === 'Update' ? this.question.IsEdit = false : this.removeQuestion.emit(this.currentQuestionOrder);
  }

  oncheckchange(event) {
    this.surveyQuestion.IsRequire = event.checked;
  }

  onMatrixTypeChange(event) {
    if (event.value === 2 || (event.value === 3)) {
      this.filterSurveyQuestionScaleType = this.surveyQuestionScaleType.filter(t => t.SurveyQuestionScaleTypeId === 1 || t.SurveyQuestionScaleTypeId === 2);
    } else {
      this.filterSurveyQuestionScaleType = JSON.parse(JSON.stringify(this.surveyQuestionScaleType));
    }
    this.selectedMatrixType = event.value;
    if (this.selectedMatrixType === 3) {
      this.subQuestionCount = this.radioButtons.filter(t => t.Text.trim() !== '').length;
      this.radioButtons.length === 0 ? this.radioButtons = JSON.parse(JSON.stringify(this.copyRadioButtons)) : this.radioButtons;
    } else {
      this.isShowSubQuestionError = false;
      this.subQuestionCount = 2;
    }
  }

  addSubQuestion() {
    let obj = {
      id: this.radioButtons.length + 1,
      Text: '',
      SurveyQuestionId: 0,
      ParentQuestionId: 0
    };
    this.radioButtons.push(obj);
  }

  removeSubQuestion(question) {
    let index = this.radioButtons.findIndex(t => t.id === question.id);
    this.radioButtons.splice(index, 1);
    if (question.SurveyQuestionId) {
      this.addQuestionService.removeQuestion(question.SurveyQuestionId).subscribe((res: any) => {
        if (res.Status == 'success') {
        } else {
          this.commonService.toaster(res.Message, false);
        }
      });
    }
  }

  getSubQuestionValues() {
    this.subQuestionCount = this.radioButtons.filter(t => t.Text.trim() !== '').length;
    this.subQuestionCount < 1 ? this.isShowSubQuestionError = true : this.isShowSubQuestionError = false;
  }

  scrollToBottom(): void {
    this.questionPanel.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'end', inline: 'start' });
  }
}
