import {
  Component,
  OnInit,
  ViewChild,
  ElementRef,
  Input,
  EventEmitter,
  Output,
  ChangeDetectionStrategy
} from "@angular/core";
import { MatDialog } from "@angular/material";
import { ConfirmDialogComponent } from "../confirm-dialog/confirm-dialog.component";
import { AddPageService } from "./add-page.service";
import { CommonService } from "src/app/core/services/common.service";
import { SurveyDetailService } from "src/app/pages/survey/survey-detail/survey-detail.service";
import { SurveyPage } from "../survey-common-pages/page.model";
import {
  SurveyQuestion,
  SurveyQuestionScaleType,
  SurveyQuestionScaleBank,
  MatrixType
} from "../add-question/question.model";
import { FormControl, Validators } from "@angular/forms";

@Component({
  selector: "app-add-page",
  templateUrl: "./add-page.component.html",
  styleUrls: ["./add-page.component.css"],
  changeDetection: ChangeDetectionStrategy.Default
})
export class AddPageComponent implements OnInit {
  @ViewChild("pagePanel", { read: ElementRef, static: false }) public pagePanel: ElementRef<any>;
  @ViewChild("AddQuestionComponent", { read: ElementRef, static: true }) childCom: ElementRef;
  @Output() addComponent = new EventEmitter<any>();
  @Output() removeComponent = new EventEmitter<any>();
  @Input() pageorder: number;
  @Input() surveyName: string;
  @Input() surveyPage: SurveyPage;
  @Input() isLive: boolean;
  @Input() matrixType: MatrixType[];
  @Input() surveyQuestionScaleType: SurveyQuestionScaleType[];
  @Input() questionScaleBank: SurveyQuestionScaleBank[];
  public questionOrder: number;
  public isEditPage: boolean;
  public newPage: SurveyPage;
  public questionLoader: boolean;
  public updatePageLoader: boolean;
  public addPageLoader: boolean;
  public isShowQuestionBtn: boolean;
  public isShowPageBtn: boolean;
  public pageTitle: string;
  public pageDescription: string;
  childQuestion: any[] = [];
  nameFormControl = new FormControl("", [Validators.required]);
  constructor(
    public dialog: MatDialog,
    private addPageService: AddPageService,
    private commonService: CommonService,
    private surveyDetailService: SurveyDetailService
  ) {}

  ngOnInit() {
    this.surveyPage.SurveyPageTypeId === null ? (this.isShowQuestionBtn = true) : (this.isShowQuestionBtn = false);
    if (this.surveyPage.SurveyPageTypeId === null || this.surveyPage.SurveyPageTypeId === 1) {
      this.isShowPageBtn = true;
    } else {
      this.isShowPageBtn = false;
    }
  }

  onAddPage() {
    this.addPageLoader = true;
    this.newPage = new SurveyPage();
    this.newPage.Name = "Page Title";
    this.newPage.Description = "";
    this.newPage.SurveyId = this.surveyPage.SurveyId;
    this.newPage.PageOrder = this.pageorder + 2;
    this.surveyDetailService.savePage(this.newPage).subscribe((res: any) => {
      if (res.Status == "success") {
        this.commonService.toaster("Page added successfully.", true);
        this.addPageLoader = false;
        this.addComponent.emit(res.Data);
      } else {
        this.commonService.toaster(res.Message, false);
        this.addPageLoader = false;
      }
    });
  }

  addQuestion(data) {
    this.addPageService.getQuestionByPage(data.SurveyId, data.SurveyPageId).subscribe((res: any) => {
      if (res.Status == "success") {
        if (res.Data.length > 0) {
          this.surveyPage = res.Data[0];
        }
      } else {
        this.commonService.toaster(res.Message, false);
      }
    });
  }

  onAddQuestioncomponent() {
    this.questionLoader = true;
    this.questionOrder = this.surveyPage.SurveyQuestion.length + 1;
    let obj = new SurveyQuestion();
    obj.IsEdit = true;
    obj.SurveyId = this.surveyPage.SurveyId;
    obj.SortOrder = this.questionOrder;
    this.surveyPage.SurveyQuestion.push(obj);
    this.questionLoader = false;
    //  this.scrollToBottom();
  }

  receiveMessage() {
    // this.addQuestion();
  }

  removeQuestion(event) {
    this.questionOrder = event;
    let Index = event - 1;
    this.surveyPage.SurveyQuestion.splice(Index, 1);
  }

  onPageEdit() {
    this.isEditPage = true;
    this.pageDescription = this.surveyPage.Description;
    this.pageTitle = this.surveyPage.Name;
  }

  updatePage() {
    if (this.pageTitle.trim() === "") {
      return false;
    }
    this.isEditPage = false;
    this.updatePageLoader = true;
    this.surveyPage.Name = this.pageTitle.trim();
    this.surveyPage.Description = this.pageDescription;
    this.addPageService.updatePage(this.surveyPage).subscribe((res: any) => {
      if (res.Status == "success") {
        this.surveyPage.Name = this.pageTitle;
        this.surveyPage.Description = this.pageDescription;
        this.commonService.toaster("Page updated successfully.", true);
      } else {
        this.commonService.toaster(res.Message, false);
      }
      this.updatePageLoader = false;
    });
  }

  closeEditPage() {
    this.isEditPage = false;
  }

  onPageDelete(id, PageOrder) {
    const dialogConfirmRef = this.dialog.open(ConfirmDialogComponent, {
      width: "350px"
    });
    dialogConfirmRef.componentInstance.message = "You want to delete this page?";
    dialogConfirmRef.componentInstance.btnOkText = "Yes";
    dialogConfirmRef.componentInstance.btnCancelText = "No";

    dialogConfirmRef.afterClosed().subscribe(result => {
      if (result === true) {
        this.addPageService.removePage(id, PageOrder).subscribe((res: any) => {
          if (res.Status == "success") {
            this.commonService.toaster("Page deleted successfully.", true);
            this.removeComponent.emit(id);
          } else {
            this.commonService.toaster(res.Message, false);
          }
        });
      }
    });
  }

  scrollToBottom(): void {
    this.pagePanel.nativeElement.scrollIntoView({ behavior: "smooth", block: "end", inline: "start" });
  }
}
