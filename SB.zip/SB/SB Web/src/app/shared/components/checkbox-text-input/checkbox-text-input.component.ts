import { Component, OnInit, Input, Output, EventEmitter, OnChanges } from '@angular/core';
import { RadioTextModel } from '../radio-text-input/radio-text.model';

@Component({
  selector: 'app-checkbox-text-input',
  templateUrl: './checkbox-text-input.component.html',
  styleUrls: ['./checkbox-text-input.component.css']
})
export class CheckboxTextInputComponent implements OnInit, OnChanges {
  @Input() textInput: any;
  @Output() messageEvent = new EventEmitter<any>();
  @Input() Options: any;
  showAdvance: boolean;
  comment: boolean;
  commentRequired: boolean;
  radioTextModel: RadioTextModel = new RadioTextModel();
  radioButtons = [{ SurveyQuestionOptionId: 1, Name: '', value: '', comment: false, commentRequired: false, SurveyQuestionScaleBankValueId: 0 },
  { SurveyQuestionOptionId: 2, Name: '', value: '', comment: false, commentRequired: false, SurveyQuestionScaleBankValueId: 0 },
  { SurveyQuestionOptionId: 3, Name: '', value: '', comment: false, commentRequired: false, SurveyQuestionScaleBankValueId: 0 },
  { SurveyQuestionOptionId: 4, Name: '', value: '', comment: false, commentRequired: false, SurveyQuestionScaleBankValueId: 0 }];

  constructor() { }

  ngOnChanges() {
    this.showAdvance = this.textInput;
    if (this.Options !== undefined) {
      this.radioButtons = this.Options;
      this.getQuestionValues();
    }
  }

  ngOnInit() {
    if (this.Options !== undefined) {
      this.radioButtons = this.Options;
      this.getQuestionValues();
    }
    this.comment = false;
    this.commentRequired = false;
  }

  showComments(event) {
    this.comment = this.comment ? false : true;
  }

  showCommentRequired() {
    this.commentRequired = this.commentRequired ? false : true;
  }

  getQuestionValues() {
    this.messageEvent.emit(this.radioButtons);
  }

  addCheckBox(rb) {
    let obj = {
      SurveyQuestionOptionId: this.radioButtons.length + 1,
      value: '',
      Name: '',
      comment: false,
      commentRequired: false,
      SurveyQuestionScaleBankValueId: 0
    };
    this.radioButtons.push(obj);
  }

  removeCheckBox(rb) {
    let index;
    if (rb.SurveyQuestionOptionId) {
      index = this.radioButtons.findIndex(t => t.SurveyQuestionOptionId === rb.SurveyQuestionOptionId);
    } else {
      index = this.radioButtons.findIndex(t => t.SurveyQuestionScaleBankValueId === rb.SurveyQuestionScaleBankValueId);
    }
    index > -1 ? this.radioButtons.splice(index, 1) : false;
    this.ngOnChanges();
  }
}
