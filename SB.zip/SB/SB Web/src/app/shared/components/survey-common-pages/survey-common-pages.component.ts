import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { MatDialog } from '@angular/material';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';
import { Page } from './page.model';

@Component({
  selector: 'app-survey-common-pages',
  templateUrl: './survey-common-pages.component.html',
  styleUrls: ['./survey-common-pages.component.css']
})
export class SurveyCommonPagesComponent implements OnInit {
  @Input() pageInput: any;
  @Input() surveyName: string;

  public pages: Page[] = [];

  constructor(
    public dialog: MatDialog,
  ) { }

  ngOnInit() {
    this.setPageObject();
  }

  setPageObject() {
    this.pageInput.forEach(item => {
      if (item.value === true) {
        this.pages.push({
          Id: item.Id,
          PageType: item.PageType, //WCPGE
          PageName: item.PageName, // Welcome Page
          PageTitle: item.PageTitle,
          PageContent: item.PageContent,
          value: item.value,
          isEdit: item.isEdit
        });
      }
    });
  }

  EditPage(page) {
    this.pages.find(t => t.Id === page.Id).isEdit = true;
  }

  closeEditWelcomePage(page) {
    this.pages.find(t => t.Id === page.Id).isEdit = false;
  }

  savePage(page) {
    this.pages.find(t => t.Id === page.Id).isEdit = false;
  }

  DeletePage(page) {
    const dialogConfirmRef = this.dialog.open(ConfirmDialogComponent, {
      width: '350px',
    });
    dialogConfirmRef.componentInstance.message = 'You want to delete this page?';
    dialogConfirmRef.componentInstance.btnOkText = 'Yes';
    dialogConfirmRef.componentInstance.btnCancelText = 'No';

    dialogConfirmRef.afterClosed().subscribe(result => {
      if (result === true) {
        let index = this.pages.indexOf(page.Id);
        this.pages.splice(index, 1);
      }
    });
  }
}
