import { SurveyQuestion } from '../add-question/question.model';

export class Page {
    Id: number;
    PageType: string;
    PageName: string;
    PageTitle: string;
    PageContent: string;
    value: boolean;
    isEdit: boolean;
}

export class SurveyPage {
    SurveyPageId: number;
    SurveyId: number;
    Name: string;
    Description: string;
    PageOrder: number;
    SurveyPageTypeId: number;
    LanguageId: number;
    SurveyPageLanguageId: number;
    SurveyQuestion: SurveyQuestion[];
}