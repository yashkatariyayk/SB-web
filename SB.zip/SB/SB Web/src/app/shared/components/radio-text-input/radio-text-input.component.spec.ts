import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RadioTextInputComponent } from './radio-text-input.component';

describe('RadioTextInputComponent', () => {
  let component: RadioTextInputComponent;
  let fixture: ComponentFixture<RadioTextInputComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RadioTextInputComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RadioTextInputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
