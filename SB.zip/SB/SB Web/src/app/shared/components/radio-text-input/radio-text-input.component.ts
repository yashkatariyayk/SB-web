import { Component, OnInit, Output, Input, EventEmitter, OnChanges } from '@angular/core';

@Component({
  selector: 'app-radio-text-input',
  templateUrl: './radio-text-input.component.html',
  styleUrls: ['./radio-text-input.component.css']
})

export class RadioTextInputComponent implements OnInit, OnChanges {

  @Input() textInput: any;
  @Output() messageEvent = new EventEmitter<any>();
  @Input() Options: any;
  @Input() selectedScale: number;
  showAdvance: boolean;
  comment: boolean;
  commentRequired: boolean;
  radioButtons = [{ SurveyQuestionOptionId: 1, Name: '', value: '', comment: false, commentRequired: false, SurveyQuestionScaleBankValueId: 0 },
  { SurveyQuestionOptionId: 2, Name: '', value: '', comment: false, commentRequired: false, SurveyQuestionScaleBankValueId: 0 },
  { SurveyQuestionOptionId: 3, Name: '', value: '', comment: false, commentRequired: false, SurveyQuestionScaleBankValueId: 0 },
  { SurveyQuestionOptionId: 4, Name: '', value: '', comment: false, commentRequired: false, SurveyQuestionScaleBankValueId: 0 }];

  constructor() { }


  ngOnChanges() {
    this.showAdvance = this.textInput;
    if (this.Options !== undefined) {
      this.radioButtons = this.Options;
      this.getQuestionValues();
    }
  }

  ngOnInit() {
    this.comment = false;
    this.commentRequired = false;
    if (this.Options !== undefined) {
      this.radioButtons = this.Options;
      this.getQuestionValues();
    }
  }

  showComments(event) {
    if (this.comment === true) {
      this.comment = false;
    } else {
      this.comment = true;
    }
  }

  showCommentRequired() {
    if (this.commentRequired === true) {
      this.commentRequired = false;
    } else {
      this.commentRequired = true;
    }
  }

  getQuestionValues() {
    this.messageEvent.emit(this.radioButtons);
  }

  addRadioButtun(rb) {
    let obj = {
      SurveyQuestionOptionId: this.radioButtons.length + 1,
      Name: '',
      value: '',
      comment: false,
      commentRequired: false,
      SurveyQuestionScaleBankValueId: 0
    };
    this.radioButtons.push(obj);
  }

  removeRadioButtun(rb) {
    let index;
    if (rb.SurveyQuestionOptionId) {
      index = this.radioButtons.findIndex(t => t.SurveyQuestionOptionId === rb.SurveyQuestionOptionId);
    } else {
      index = this.radioButtons.findIndex(t => t.SurveyQuestionScaleBankValueId === rb.SurveyQuestionScaleBankValueId);
    }
    index > -1 ? this.radioButtons.splice(index, 1) : false;
    this.ngOnChanges();
  }
}
