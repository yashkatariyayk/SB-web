import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
  name: "multiselectValueFilter",
  pure: true
})
export class MultiselectValueFilterPipe implements PipeTransform {
  transform(source: any[], option: string): boolean {
    if (source && source.length > 0) {
      if (source[0].SurveyQuestionOptionId) {
        let exist = source.filter(x => x.SurveyQuestionOptionId == option)[0];
        if (exist) return true;
      } else {
        let exist = source.filter(x => x == option)[0];
        if (exist) return true;
      }
    }
    return false;
  }
}
