import { NgModule } from '@angular/core';
// Material
import {
    MatSidenavModule, MatFormFieldModule, MatButtonModule,
    MatToolbarModule, MatIconModule, MatListModule,
    MatMenuModule, MatCardModule, MatInputModule,
    MatProgressSpinnerModule, MatTableModule, MatDialogModule,
    MatPaginatorModule, MatSortModule, MatCheckboxModule,
    MatTooltipModule, MatStepperModule, MatExpansionModule,
    MatDatepicker, MatDatepickerModule, MatNativeDateModule,
    MatSelectModule, MatGridListModule, MatTreeModule, MatTabsModule,
    MatAutocompleteModule,
    MatSlideToggleModule,
    MatRadioModule,
    MatSliderModule
} from '@angular/material';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
// import { SharedService } from './shared.service';
import { NgSlimScrollModule, SLIMSCROLL_DEFAULTS } from 'ngx-slimscroll';
import { SatDatepickerModule, SatNativeDateModule } from 'saturn-datepicker';
import { CKEditorModule } from 'ng2-ckeditor';
// image Cropper Module
import { ImageCropperModule } from 'ngx-image-cropper';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { AddPageComponent } from './components/add-page/add-page.component';
import { SurveyCommonPagesComponent } from './components/survey-common-pages/survey-common-pages.component';
import { AddQuestionComponent } from './components/add-question/add-question.component';
import { RadioTextInputComponent } from './components/radio-text-input/radio-text-input.component';
import { CheckboxTextInputComponent } from './components/checkbox-text-input/checkbox-text-input.component';
import { ConfirmDialogComponent } from './components/confirm-dialog/confirm-dialog.component';
import { DateRangePickerComponent } from './components/date-range-picker/date-range-picker.component';
import { ErrorDialogComponent } from './components/error-dialog/error-dialog.component';
import { DateFormateModule } from './pipes/date-formate/date-formate.module';
import { DateFormatePipe } from './pipes/date-formate/date-formate.pipe';
import { AddQuestionService } from './components/add-question/add-question.service';
import { AddPageService } from './components/add-page/add-page.service';
import { LoaderComponent } from './components/loader/loader.component';
import { LaddaModule } from 'angular2-ladda';
import { EmployeeMatrixSingleChoiseComponent } from './components/employee-matrix-single-choise/employee-matrix-single-choise.component';
import { EmployeeMatrixMultiChoiseComponent } from './components/employee-matrix-multi-choise/employee-matrix-multi-choise.component';
import { SelectAutocompleteModule } from 'mat-select-autocomplete';
import { EditableMultiselectDropdownComponent } from './components/editable-multiselect-dropdown/editable-multiselect-dropdown.component';
import { QuestionMatrixComponent } from './components/question-matrix/question-matrix.component';
import { InfiniteScrollModule } from './pipes/infinite-scroll/infinite-scroll.module';
@NgModule({
    declarations: [
        AddPageComponent,
        SurveyCommonPagesComponent,
        AddQuestionComponent,
        RadioTextInputComponent,
        CheckboxTextInputComponent,
        ConfirmDialogComponent,
        DateRangePickerComponent,
        ErrorDialogComponent,
        LoaderComponent,
        DateFormatePipe,
        EmployeeMatrixSingleChoiseComponent,
        EmployeeMatrixMultiChoiseComponent,
        EditableMultiselectDropdownComponent,
        QuestionMatrixComponent
    ],
    imports: [
        CommonModule,
        ReactiveFormsModule,
        FormsModule,
        MatMenuModule,
        MatCardModule,
        MatFormFieldModule,
        MatInputModule,
        MatProgressSpinnerModule,
        MatTableModule,
        MatDialogModule,
        MatPaginatorModule,
        MatSortModule,
        MatCheckboxModule,
        MatSelectModule,
        MatTooltipModule,
        MatStepperModule,
        MatSidenavModule, MatButtonModule, MatToolbarModule, MatIconModule, MatListModule,
        MatExpansionModule,
        MatDatepickerModule,
        MatNativeDateModule,
        MatGridListModule,
        RouterModule,
        NgSlimScrollModule,
        MatTreeModule,
        MatTabsModule,
        DragDropModule,
        MatAutocompleteModule,
        MatSlideToggleModule,
        MatRadioModule,
        MatSliderModule,
        // Image Cropper
        ImageCropperModule,
        SatDatepickerModule,
        SatNativeDateModule,
        CKEditorModule,
        DateFormateModule,
        LaddaModule,
        SelectAutocompleteModule
    ],
    exports: [
        // Component
        AddPageComponent,
        SurveyCommonPagesComponent,
        AddQuestionComponent,
        RadioTextInputComponent,
        CheckboxTextInputComponent,
        ConfirmDialogComponent,
        DateRangePickerComponent,
        ErrorDialogComponent,
        LoaderComponent,
        // Modules
        CommonModule,
        ReactiveFormsModule,
        FormsModule,
        MatMenuModule,
        MatCardModule,
        MatFormFieldModule,
        MatInputModule,
        MatProgressSpinnerModule,
        MatTableModule,
        MatDialogModule,
        MatPaginatorModule,
        MatSortModule,
        MatCheckboxModule,
        MatTooltipModule,
        MatStepperModule,
        MatSidenavModule, MatButtonModule, MatToolbarModule, MatIconModule, MatListModule,
        MatExpansionModule,
        MatSelectModule,
        MatDatepickerModule,
        MatNativeDateModule,
        MatGridListModule,
        RouterModule,
        NgSlimScrollModule,
        MatTreeModule,
        MatTabsModule,
        DragDropModule,
        MatAutocompleteModule,
        MatSlideToggleModule,

        // Image Cropper
        ImageCropperModule,

        // DateRangePicker
        SatDatepickerModule,
        SatNativeDateModule,
        DateFormatePipe,
        InfiniteScrollModule
    ],
    providers: [
        AddPageService,
        AddQuestionService,
        DatePipe,
        {
            provide: SLIMSCROLL_DEFAULTS,
            useValue: {
                alwaysVisible: false,
                gridOpacity: '0.2', barOpacity: '0.5',
                gridBackground: '#fff',
                gridWidth: '6',
                gridMargin: '2px 2px',
                barBackground: '#fff',
                barWidth: '20',
                barMargin: '2px 2px'
            }
        }
    ],
    entryComponents: [
        // ViewTeamComponent,
        ConfirmDialogComponent,
        ErrorDialogComponent

    ]
})
export class SharedModule { }
