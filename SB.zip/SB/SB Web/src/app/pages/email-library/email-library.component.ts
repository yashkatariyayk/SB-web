import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-email-library',
  templateUrl: './email-library.component.html',
  styleUrls: ['./email-library.component.scss']
})
export class EmailLibraryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
