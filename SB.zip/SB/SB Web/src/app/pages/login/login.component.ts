import { Component, OnInit, Inject, LOCALE_ID } from "@angular/core";
import { Router } from "@angular/router";
import { LoginService } from "./login.service";
import { CommonService } from "src/app/core/services/common.service";
import { Login } from "./login.model";

@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.css"]
})
export class LoginComponent implements OnInit {
  public checked: boolean;
  public loader: boolean;
  loginModal: Login = new Login();

  constructor(
    private router: Router,
    private commonService: CommonService,
    private loginService: LoginService
  ) {}

  ngOnInit() {
    let isRememberMe = localStorage.getItem("isRememberMe");
    if (isRememberMe == "true") {
      // this.router.navigate(['./dashboard']);
      this.router.navigate(["./survey"]);
    }
  }

  onChange(event) {
    this.checked = event.checked;
  }

  onSubmitButtonClick() {
    this.loader = true;
    let encodedData = window.btoa(this.loginModal.User.Password);
    console.log(encodedData);

    this.loginModal.User.Password = encodedData;
    if (this.checked) {
      localStorage.setItem("isRememberMe", "true");
    }
    this.loginService
      .login("/auth/token", this.loginModal)
      .subscribe((res: any) => {
        if (res.Status == "success") {
          localStorage.setItem("access_token", res.Token);
          localStorage.setItem("UserName", res.Data.FirstName);
          this.loader = false;
          // this.router.navigate(['./dashboard']);
          this.router.navigate(["./survey"]);
        } else {
          this.commonService.toaster(res.Message, false);
          this.loader = false;
        }
      });
  }
}
