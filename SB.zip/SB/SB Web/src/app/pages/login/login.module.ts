import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { SharedModule } from "src/app/shared/shared.module";
import { LoginComponent } from "./login.component";
import { LoginService } from "./login.service";
import { FormsModule } from "@angular/forms";
import { ToasterModule } from "angular2-toaster";
import { LaddaModule } from "angular2-ladda";

const routes: Routes = [{ path: "", component: LoginComponent }];

@NgModule({
  declarations: [LoginComponent],
  imports: [
    FormsModule,
    SharedModule,
    ToasterModule,
    RouterModule.forChild(routes),
    LaddaModule
  ],
  providers: [LoginService],
  exports: [RouterModule]
})
export class LoginModule {}
