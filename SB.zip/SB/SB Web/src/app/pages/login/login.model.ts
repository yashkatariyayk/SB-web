export class User {
  UserName: string;
  Password: string;
}

export class Login {
  User: User;
  constructor() {
    this.User = new User();
  }
}
