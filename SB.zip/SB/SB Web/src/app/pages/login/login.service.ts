import { Injectable } from "@angular/core";
import { environment } from "src/environments/environment";
import { HttpClientService } from "src/app/core/services/http-client.service";
@Injectable()
export class LoginService {
  baseURL: string = environment.APIURL;

  constructor(private httpClient: HttpClientService) {}

  login(url, data: any) {
    return this.httpClient.post(url, data);
  }

  get(url) {
    return this.httpClient.get(url);
  }
}
