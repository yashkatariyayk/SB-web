import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { CreateSurveyComponent } from "./create-survey.component";
import { Routes, RouterModule } from "@angular/router";
import { SharedModule } from "src/app/shared/shared.module";
import { CreateSurveyService } from "./create-survey.service";
import { ToasterService, ToasterModule } from "angular2-toaster";

const routes: Routes = [
  {
    path: "",
    component: CreateSurveyComponent,
    data: {
      title: "Create Survey",
      breadcrumb: [
        {
          label: "Create Survey",
          url: ""
        }
      ]
    }
  }
];

@NgModule({
  declarations: [CreateSurveyComponent],
  imports: [
    CommonModule,
    SharedModule,
    ToasterModule,
    RouterModule.forChild(routes)
  ],
  providers: [CreateSurveyService, ToasterService]
})
export class CreateSurveyModule {}
