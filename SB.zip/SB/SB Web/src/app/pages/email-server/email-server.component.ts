import { Component, OnInit } from "@angular/core";
import { EmailServer } from "./email-server.model";
import { MatTableDataSource } from "@angular/material";
import { EmailServerService } from "./email-server.service";

@Component({
  selector: "app-email-server",
  templateUrl: "./email-server.component.html",
  styleUrls: ["./email-server.component.scss"]
})
export class EmailServerComponent implements OnInit {
  constructor(private emailServerService: EmailServerService) {}

  public emailServerList: EmailServer[] = [];
  dataSource = new MatTableDataSource<EmailServer>(this.emailServerList);
  public displayedColumns: string[] = [
    "UserName",
    "Host",
    "Email",
    "Port",
    "IsActive"
  ];

  ngOnInit() {
    this.getEmailConfigurationList();
    this.dataSource = new MatTableDataSource<EmailServer>(this.emailServerList);
  }
  getEmailConfigurationList() {
    this.emailServerService.get().subscribe(data => {
      this.emailServerList = data.Data;
    });
  }
  getIsActive(event, emailServerObj) {
    this.emailServerService
      .update(emailServerObj.EmailConfigId)
      .subscribe(res => {
        console.log(res);
        this.getEmailConfigurationList();
      });
  }
}
