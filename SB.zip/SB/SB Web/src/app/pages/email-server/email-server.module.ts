import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { SharedModule } from "src/app/shared/shared.module";
import { Routes, RouterModule } from "@angular/router";
import { MatFormFieldModule, MatInputModule } from "@angular/material";
import { LaddaModule } from "angular2-ladda";
import { EmailServerComponent } from "./email-server.component";
import { EmailServerService } from "./email-server.service";

const routes: Routes = [
  {
    path: "",
    component: EmailServerComponent,
    data: {
      title: "Email Server",
      breadcrumb: [
        {
          label: "Email Server",
          url: ""
        }
      ]
    }
  }
];
@NgModule({
  declarations: [EmailServerComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    SharedModule,
    MatFormFieldModule,
    MatInputModule,
    LaddaModule
  ],
  exports: [EmailServerComponent],
  providers: [EmailServerService],
  entryComponents: []
})
export class EmailServerModule {}
