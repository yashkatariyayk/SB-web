export class Language {
    LanguageId: number;
    Name: string;
    CodeName: string;
    CreatedOn: string;
    CreatedBy: string;
    Orientation: string;
    IsActive: boolean;
    Selected: boolean;
    IsDeleted: boolean;
}