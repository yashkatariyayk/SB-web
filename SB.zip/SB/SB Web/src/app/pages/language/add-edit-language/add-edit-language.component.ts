import { Component, OnInit, Inject } from "@angular/core";
import { CommonService } from "src/app/core/services/common.service";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import { Language } from "../language";
import { FormControl, Validators } from "@angular/forms";
import { LanguageService } from "../language.service";

@Component({
  selector: "app-add-edit-language",
  templateUrl: "./add-edit-language.component.html",
  styleUrls: ["./add-edit-language.component.scss"]
})
export class AddEditLanguageComponent implements OnInit {
  constructor(
    public dialogRef: MatDialogRef<AddEditLanguageComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private languageService: LanguageService,
    private commonService: CommonService
  ) {}

  language = new Language();
  public loader: boolean;
  languageFormControl = new FormControl("", [Validators.required]);

  ngOnInit() {
    this.language = new Language();
    this.language.Orientation = "LTR";
  }

  onCancelClick(): void {
    this.dialogRef.close(false);
  }

  updateLanguage() {
    this.loader = true;
    if (this.language.Name === undefined || this.language.Name === "") {
      this.loader = false;
      return false;
    } else {
      this.language.CodeName = this.language.Name.substring(0, 2);
      this.language.CreatedBy = localStorage.getItem("UserName");
      this.language.CreatedOn = new Date().toString();
      this.languageService.addLanguage(this.language).subscribe((res: any) => {
        if (res.Status == "success") {
          this.loader = false;
          this.dialogRef.close(true);
        } else {
          this.loader = false;
          this.commonService.toaster(res.Message, false);
        }
      });
    }
  }
}
