import {
  Component,
  OnInit,
  ChangeDetectorRef,
  AfterViewChecked
} from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { SurveyDetailService } from "../survey/survey-detail/survey-detail.service";
import { CommonService } from "src/app/core/services/common.service";
import { SurveyDetail } from "../survey/survey-detail/survey-detail.model";
import { Language } from "../language/language";
import { LanguageService } from "../language/language.service";
import { SurveyPage } from "../../shared/components/survey-common-pages/page.model";
import { environment } from "src/environments/environment";

@Component({
  selector: "app-preview-survey",
  templateUrl: "./preview-survey.component.html",
  styleUrls: ["./preview-survey.component.scss"]
})
export class PreviewSurveyComponent implements OnInit, AfterViewChecked {
  public surveyId: number;
  public loader: boolean;
  public languages: Language[] = [];
  public surveyDetail: SurveyDetail = new SurveyDetail();
  public surveyPage: SurveyPage;
  public childQuestion: any[] = [];
  public _ImageUrl: string = environment.IMAGEURL;

  constructor(
    private route: ActivatedRoute,
    private surveyDetailService: SurveyDetailService,
    private languageService: LanguageService,
    private commonService: CommonService,
    private cdRef: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this.route.params.subscribe(queryParams => {
      let surveyId = queryParams["id"];
      if (surveyId !== undefined) {
        this.surveyId = surveyId;
      }
    });
    this.getSurvey(this.surveyId);
    this.getLanguageList();
  }

  public getSurvey(id) {
    this.loader = true;
    this.surveyDetailService.getSurvey(id).subscribe((res: any) => {
      if (res.Status == "success") {
        if (res.Data !== null || res.Data !== undefined) {
          if (res.Data.length > 0) {
            this._ImageUrl = environment.IMAGEURL;
            let surveyDetail = res.Data[0];
            if (surveyDetail.surveyPage.length > 0) {
              let closedPageContent = surveyDetail.surveyPage.pop();
              let alreadySubmittedPageContent = surveyDetail.surveyPage.pop();
              this.surveyDetail = surveyDetail;
            }
          }
        }
        this.loader = false;
      } else {
        this.loader = false;
        this.commonService.toaster(res.Message, false);
      }
    });
  }

  getLanguageList() {
    this.loader = true;
    this.languageService.languageList().subscribe((res: any) => {
      if (res.Status == "success") {
        if (res.Data !== null || res.Data !== undefined) {
          this.languages = res.Data;
        }
      } else {
        this.commonService.toaster(res.Message, false);
      }
      this.loader = false;
    });
  }

  ngAfterViewChecked() {
    this.cdRef.detectChanges();
  }
}
