import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExportSurveyComponent } from './export-survey.component';

describe('ExportSurveyComponent', () => {
  let component: ExportSurveyComponent;
  let fixture: ComponentFixture<ExportSurveyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExportSurveyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExportSurveyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
