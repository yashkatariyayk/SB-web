import { Component, OnInit, Input } from "@angular/core";
import { CommonService } from "src/app/core/services/common.service";
import { SurveyDetailService } from "../survey-detail.service";
import { ExportSurveyResponse } from "./export-survey-response.model";
import { DatePipe } from "@angular/common";

@Component({
  selector: "app-export-survey",
  templateUrl: "./export-survey.component.html",
  styleUrls: ["./export-survey.component.scss"]
})
export class ExportSurveyComponent implements OnInit {
  @Input() surveyId: number;
  @Input() surveyName: string;

  public sampleHeader: any[] = [
    "Selector ID",
    "Selector Email Address",
    "Question ID",
    "Question Text",
    "Question Type",
    "Matrix Question ID",
    "Matrix Question Text",
    "Selectee ID",
    "Selectee Email Address",
    "Response"
  ];
  public ExportSurveyResponse: ExportSurveyResponse[];
  public today: string;

  constructor(private commonService: CommonService, private surveyDetailService: SurveyDetailService) { }

  ngOnInit() {
    this.ExportSurveyResponse = [];
    let datePipe = new DatePipe("en-US");
    this.today = datePipe.transform(new Date(), "yyyyMMdd");
  }

  ExportSurveyReport() {
    this.surveyDetailService.getSurveyResponse(this.surveyId).subscribe((res: any) => {
      if (res.Status == "success") {
        if (res.Data.length > 0) {
          this.ExportSurveyResponse = [];
          let responseArr = res.Data;
          this.GetResponseData(responseArr);
          this.exportCSVFile(
            this.sampleHeader,
            this.ExportSurveyResponse,
            "Client-" + this.surveyName + "-" + this.today + "-Responses"
          );
        } else {
          this.commonService.toaster("No data to Export.", false);
        }
        // this.commonService.toaster(res.Message, true);
      } else {
        this.commonService.toaster(res.Message, false);
      }
    });
  }

  async GetResponseData(responseArr) {
    responseArr.forEach(element => {
      let selector = element.selector[0];
      element.ResponseLink.forEach(response => {
        let Obj = new ExportSurveyResponse();
        Obj.SelectorID = selector.SurveySelectorId;
        Obj.SelectorEmailAddress = selector.Email.replace(/,/g, " ").trim();
        Obj.QuestionID = element.SurveyQuestionId;
        Obj.QuestionText = element.Question.Name.replace(/,/g, " ").trim();
        Obj.QuestionType = element.Question.Scale.Name.replace(/,/g, " ").trim();
        Obj.MatrixQuestionID = response.MatrixTableRecordId ? response.MatrixTableRecordId : 0;
        Obj.MatrixQuestionText = response.QuetionMatrixText ? response.QuetionMatrixText.Name.replace(/,/g, " ").trim() : "";
        if (response.Selectee.length > 0) {
          Obj.SelecteeID = response.Selectee[0].SurveySelecteeId;
          Obj.SelecteeEmailAddress = response.Selectee[0].Email.replace(/,/g, " ").trim();
        } else {
          Obj.SelecteeID = 0;
          Obj.SelecteeEmailAddress = "";
        }
        Obj.Response = (response.Value === null ? '' : response.Value.replace(/,/g, " ").trim());
        this.ExportSurveyResponse.push(Obj);
      });
    });
  }

  exportCSVFile(headers, items, fileTitle) {
    if (headers) {
      items.unshift(headers);
    }

    // Convert Object to JSON
    let jsonObject = JSON.stringify(items);

    let csv = this.convertToCSV(jsonObject);

    let exportedFilenmae = fileTitle + ".csv" || "exportSurveyResponse.csv";

    let blob = new Blob(['\ufeff' + csv], { type: "text/csv; charset=utf8;" });
    if (navigator.msSaveBlob) {
      // IE 10+
      navigator.msSaveBlob(blob, exportedFilenmae);
    } else {
      let link = document.createElement("a");
      if (link.download !== undefined) {
        // feature detection
        // Browsers that support HTML5 download attribute
        let url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", exportedFilenmae);
        link.style.visibility = "hidden";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }
    }
  }

  convertToCSV(objArray) {
    let array = typeof objArray != "object" ? JSON.parse(objArray) : objArray;
    let str = "";

    for (let i = 0; i < array.length; i++) {
      let line = "";
      for (let index in array[i]) {
        if (line != "") line += ",";

        line += array[i][index];
      }
      str += line + "\r\n";
    }
    return str;
  }
}
