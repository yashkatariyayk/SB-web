import { SurveyDetail } from "../survey-detail.model";
import { SurveyPage } from "src/app/shared/components/survey-common-pages/page.model";
import { SurveyQuestion, SurveyQuestionOption } from "src/app/shared/components/add-question/question.model";

export class ExportSurvey {
  Id: number;
  PageId: number;
  QuestionId: number;
  ParentQuestionId: number;
  Code: string;
  Language: string;
  //  Value: string;
  Title: string;
  Description: string;
  //   TargetValue: string;
  TargetTitle: string;
  TargetDescription: string;
  TranslatedId: number;
}

export class SurveySelecteeLanguage {
  SurveySelecteeLanguageId: number;
  SurveySelecteeId: number;
  FirstName: string;
  LastName: string;
  Email: string;
  Role: string;
  Department: string;
  Miscellaneous: string;
  LanguageId: number;
  TranslatedId: number;
}

export class ImportSurvey {
  Survey: SurveyDetail[];
  SurveyPage: SurveyPage[];
  SurveyQuestions: SurveyQuestion[];
  SurveyQuestionOptions: SurveyQuestionOption[];
}

export class EmailTemplateLanguage {
  EmailTemplateLanguageId: number;
  EmailTemplateId: number;
  LanguageId: number;
  Subject: string;
  Body: string;
}

export class ExportEmailTemplate {
  Id: number;
  Title: string;
  Subject: string;
  Body: string;
  TargetSubject: string;
  TargetBody: string;
  TranslateId: number;
}

export class ExportStaticContent {
  Id: number;
  Code: string;
  Name: string;
  Value: string;
  TargetValue: string;
  TranslatedId: number;
}

export class StaticContentLanguage {
  StaticContentLanguageId: number;
  StaticContentId: number;
  SurveyId: number;
  LanguageId: number;
  Value: string;
}
