import { Injectable } from "@angular/core";
import { HttpClientService } from "src/app/core/services/http-client.service";

@Injectable({
  providedIn: "root"
})
export class LanguageService {
  constructor(private httpClient: HttpClientService) {}

  getQuestionList(surveyId: number) {
    let url = "/survey/question?surveyId=" + surveyId;
    return this.httpClient.get(url);
  }

  getPageList(surveyId: number) {
    let url = "/survey/page?SurveyId=" + surveyId;
    return this.httpClient.get(url);
  }

  getEmailTemplate(languageId) {
    let url = "/emailTemplate?languageId=" + languageId;
    return this.httpClient.get(url);
  }

  getSelecteeList(SurveyId, languageId, filterObject) {
    let url = "/survey/selectee/" + SurveyId + "/?languageId=" + languageId;
    return this.httpClient.post(url, filterObject);
  }

  getStaticContent(languageId, surveyId) {
    let url = "/survey/static?languageId=" + languageId + "&surveyId=" + surveyId;
    return this.httpClient.get(url);
  }

  saveImportedSurvey(survey: any) {
    let url = "/survey/language";
    return this.httpClient.post(url, survey);
  }

  saveImportedEmailTemplate(emailTemplate: any) {
    let url = "/survey/emailTemplate/language";
    return this.httpClient.post(url, emailTemplate);
  }

  saveImportedSelectee(selectee: any) {
    let url = "/selectee/language";
    return this.httpClient.post(url, selectee);
  }

  saveImportedStaticContent(staticContent: any) {
    let url = "/survey/static/language";
    return this.httpClient.post(url, staticContent);
  }

  getSurvey(id, languageId) {
    let url = "/survey?id=" + id + "&languageId=" + languageId;
    return this.httpClient.get(url);
  }

  languageList() {
    let url = "/language";
    return this.httpClient.get(url);
  }
}
