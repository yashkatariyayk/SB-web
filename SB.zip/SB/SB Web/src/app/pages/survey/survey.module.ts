import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { Routes, RouterModule } from "@angular/router";
import { SharedModule } from "src/app/shared/shared.module";
import { NgCircleProgressModule } from "ng-circle-progress";
import { AuthGuard } from "src/app/core/services/auth-guard.service";
import { DateFormatePipe } from "src/app/shared/pipes/date-formate/date-formate.pipe";
import { DateFormateModule } from "src/app/shared/pipes/date-formate/date-formate.module";

const routes: Routes = [
  {
    path: "",
    loadChildren: "./survey-list/survey-list.module#SurveyListModule",
    data: {
      title: "Survey",
      breadcrumb: [
        {
          label: "Dashboard",
          url: "/dashboard"
        },
        {
          label: "Survey",
          url: ""
        }
      ]
    }
  },
  {
    path: "survey-detail/:id",
    loadChildren: "./survey-detail/survey-detail.module#SurveyDetailModule",
    data: {
      title: "Survey Detail",
      //  selectedIndex: 0,
      breadcrumb: [
        {
          label: "Dashboard",
          url: "/dashboard"
        },
        {
          label: "Survey",
          url: "/survey"
        },
        {
          label: "Survey Detail",
          url: ""
        }
      ]
    }
  },
  {
    path: "survey-detail/:id/:tabId",
    loadChildren: "./survey-detail/survey-detail.module#SurveyDetailModule",
    data: {
      title: "Survey Detail",
      breadcrumb: [
        {
          label: "Dashboard",
          url: "/dashboard"
        },
        {
          label: "Survey",
          url: "/survey"
        },
        {
          label: "Survey Detail",
          url: ""
        }
      ]
    }
  }
];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    SharedModule,
    DateFormateModule,
    RouterModule.forChild(routes),
    NgCircleProgressModule.forRoot({
      radius: 17,
      space: -3,
      outerStrokeWidth: 3,
      innerStrokeWidth: 3,
      showTitle: false,
      showUnits: false,
      clockwise: true
    })
  ],
  exports: [RouterModule]
})
export class SurveyModule {}
