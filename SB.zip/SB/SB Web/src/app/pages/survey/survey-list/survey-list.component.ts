import { Component, OnInit, ViewChild } from "@angular/core";
import { MatSort, MatTableDataSource, MatDialog } from "@angular/material";
import { CommonService } from "../../../core/services/common.service";
import { Router } from "@angular/router";
import { Survey, SurveyStatus, FilterObject } from "./survey-list.model";
import { FormControl } from "@angular/forms";
import { SurveyListService } from "./survey-list.service";
import { ConfirmDialogComponent } from "src/app/shared/components/confirm-dialog/confirm-dialog.component";
import { UtilityComponent } from "src/app/core/services/utility";

@Component({
  selector: "app-survey-list",
  templateUrl: "./survey-list.component.html",
  styleUrls: ["./survey-list.component.scss"]
})
export class SurveyListComponent implements OnInit {
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  public show: boolean;
  public loader: boolean = true;
  public displayedColumns: string[] = [
    "SurveyStatusName",
    "Name",
    "ClientName",
    "CreatedOn"
  ];
  public globalFilter: string;
  public filteredValues: FilterObject = new FilterObject();
  public previousfilteredDatasource: any;
  clientFilter = new FormControl();
  nameFilter = new FormControl();
  statusFilter = new FormControl();
  dateFilter = new FormControl();
  surveyList: Survey[] = [];
  dataSource = new MatTableDataSource<Survey>(this.surveyList);
  statusList: SurveyStatus[] = [];

  constructor(
    private router: Router,
    public dialog: MatDialog,
    private commonService: CommonService,
    private surveyListService: SurveyListService
  ) {}

  ngOnInit() {
    this.show = false;
    this.globalFilter = "";
    this.dataSource = new MatTableDataSource<Survey>(this.surveyList);
    this.getSurveyList();
    this.getStatusList();

    this.clientFilter.valueChanges.subscribe(clientFilterValue => {
      if (clientFilterValue) {
        this.filteredValues["Client"] = clientFilterValue.trim();
      } else {
        delete this.filteredValues.Client;
      }
      this.getSurveyList();
    });

    this.nameFilter.valueChanges.subscribe(titleFilterValue => {
      if (titleFilterValue) {
        this.filteredValues["Name"] = titleFilterValue.trim();
      } else {
        delete this.filteredValues.Name;
      }
      this.getSurveyList();
    });

    this.statusFilter.valueChanges.subscribe(statusFilterValue => {
      if (statusFilterValue != 0) {
        this.filteredValues["SurveyStatusId"] = statusFilterValue;
      } else {
        delete this.filteredValues.SurveyStatusId;
      }
      this.getSurveyList();
    });
    this.dataSource.sort = this.sort;
  }

  getSurveyList() {
    let filterObject = this.filteredValues;
    this.surveyListService.surveyList(filterObject).subscribe((res: any) => {
      if (res.Status == "success") {
        if (res.Data !== null || res.Data !== undefined) {
          this.surveyList = res.Data;
          this.dataSource.data = res.Data as Survey[];
          this.dataSource.data.forEach(element => {
            element.SurveyStatusName = element.SurveyStatus.Name;
            element.ClientName = element.Client.Name;
            element.CreatedOn = UtilityComponent.convertUTCDateToLocalDate(
              element.CreatedOn
            );
          });
        }
        this.loader = false;
      } else {
        this.commonService.toaster(res.Message, false);
      }
    });
  }

  getStatusList() {
    this.surveyListService.statusList().subscribe((res: any) => {
      if (res.Status == "success") {
        this.statusList = res.Data;
      } else {
        this.commonService.toaster(res.Message, false);
      }
    });
  }

  onSurveyTitleLinkClick(surveyId) {
    this.router.navigate(["/survey/survey-detail/" + surveyId]);
  }

  applyFilter(filter) {
    this.globalFilter = filter;
    this.dataSource.filter = JSON.stringify(this.filteredValues);
  }

  dateoutput(event) {
    if (event) {
      this.filteredValues["StartDate"] = UtilityComponent.getUTCDate(
        new Date(event.startDate)
      );
      this.filteredValues["EndDate"] = UtilityComponent.getUTCDate(
        new Date(new Date(event.endDate).setHours(23, 59, 59))
      );
    } else {
      delete this.filteredValues.StartDate;
      delete this.filteredValues.EndDate;
    }
    this.getSurveyList();
  }

  onCopySurvey(survey: any) {
    this.loader = true;
    let obj = {
      Name: survey.Name,
      SurveyId: survey.SurveyId,
      ClientId: survey.ClientId
    };
    this.surveyListService.copySurvey(obj).subscribe((res: any) => {
      if (res.Status == "success") {
        let surveyId = res.Data.SurveyId;
        this.commonService.toaster("Survey copied successfully.", true);
        this.router.navigate(["/survey/survey-detail/" + surveyId]);
      } else {
        this.commonService.toaster(res.Message, false);
      }
      this.loader = false;
    });
  }

  onSurveyDelete(survey: any) {
    const dialogConfirmRef = this.dialog.open(ConfirmDialogComponent, {
      width: "350px"
    });
    dialogConfirmRef.componentInstance.message =
      "You want to delete this survey?";
    dialogConfirmRef.componentInstance.btnOkText = "Yes";
    dialogConfirmRef.componentInstance.btnCancelText = "No";

    dialogConfirmRef.afterClosed().subscribe(result => {
      if (result === true) {
        this.loader = true;
        this.surveyListService
          .removeSurvey(survey.SurveyId)
          .subscribe((res: any) => {
            if (res.Status == "success") {
              this.commonService.toaster("Survey deleted successfully.", true);
              this.getSurveyList();
            } else {
              this.commonService.toaster(res.Message, false);
            }
            this.loader = false;
          });
      }
    });
  }

  onUpdateSurveyStatus(survey: Survey, SurveyStatusId: number) {
    const dialogConfirmRef = this.dialog.open(ConfirmDialogComponent, {
      width: "350px"
    });
    SurveyStatusId === 3
      ? (dialogConfirmRef.componentInstance.message =
          "You want to pause this survey?")
      : (dialogConfirmRef.componentInstance.message =
          "You want to close this survey?");
    dialogConfirmRef.componentInstance.btnOkText = "Yes";
    dialogConfirmRef.componentInstance.btnCancelText = "No";

    dialogConfirmRef.afterClosed().subscribe(result => {
      if (result === true) {
        this.loader = true;
        let Obj = {
          SurveyStatusId: SurveyStatusId
        };
        this.surveyListService
          .updateSurveyStatus(survey.SurveyId, Obj)
          .subscribe((res: any) => {
            if (res.Status == "success") {
              this.commonService.toaster(
                "Survey status updated successfully.",
                true
              );
              this.getSurveyList();
            } else {
              this.commonService.toaster(res.Message, false);
            }
            this.loader = false;
          });
      }
    });
  }

  handleInput(event, InputName) {
    if (InputName === "clientName") {
      if (event.which === 32 && this.clientFilter.value.length === 1) {
        this.clientFilter.setValue(null);
        event.preventDefault();
      }
    } else {
      if (event.which === 32 && this.nameFilter.value.length === 1) {
        this.nameFilter.setValue(null);
        event.preventDefault();
      }
    }
  }
}
