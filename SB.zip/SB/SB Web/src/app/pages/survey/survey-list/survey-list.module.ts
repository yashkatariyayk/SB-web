import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SurveyListComponent } from './survey-list.component';
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from 'src/app/shared/shared.module';
import { NgCircleProgressModule } from 'ng-circle-progress';
import { SurveyListService } from './survey-list.service';
const routes: Routes = [
  { path: '', component: SurveyListComponent }
];
@NgModule({
  declarations: [SurveyListComponent],
  imports: [
    CommonModule,
    SharedModule,
    RouterModule.forChild(routes),
    NgCircleProgressModule.forRoot({
      radius: 17,
      space: -3,
      outerStrokeWidth: 3,
      innerStrokeWidth: 3,
      showTitle: false,
      showUnits: false,
      clockwise: true,
    }),
  ],
  providers: [
    SurveyListService
],
})
export class SurveyListModule { }
