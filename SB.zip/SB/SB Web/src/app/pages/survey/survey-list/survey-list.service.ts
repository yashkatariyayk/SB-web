import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClientService } from 'src/app/core/services/http-client.service';
@Injectable()
export class SurveyListService {

    baseURL: string = environment.APIURL;

    constructor(private httpClient: HttpClientService) { }

    surveyList(filterObject) {
        let url = '/all/survey';
        return this.httpClient.post(url, filterObject);
    }

    statusList() {
        let url = '/survey/status';
        return this.httpClient.get(url);
    }

    removeSurvey(id) {
        let url = '/survey?id=' + id;
        return this.httpClient.delete(url);
    }

    copySurvey(survey: any) {
        let url = '/copy/survey';
        return this.httpClient.post(url, survey);
    }

    updateSurveyStatus(surveyId, survey: any){
        let url = '/survey?id=' + surveyId;
        return this.httpClient.put(url, survey);
    }

}