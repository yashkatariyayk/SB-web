import { SurveyQuestion, SurveyQuestionOption } from 'src/app/shared/components/add-question/question.model';
import { SurveyPage } from 'src/app/shared/components/add-page/page.model';

export interface Status {
    value: string;
    viewValue: string;
}

export class SurveyStatus {
    SurveyStatusId: number;
    Name: string;
}

export class Survey {
    SurveyId: number;
    Name: string;
    StartDate: string;
    EndDate: string;
    IsDeleted: boolean;
    CreatedBy: string;
    CreatedOn: Date;
    ThemeId: number;
    SurveyStatusId: number;
    SurveyStatusName: string;
    ClientName: string;
    ClientId: number;
    IsTemplate: boolean;
    LogoName: string;
    SurveyStatus: SurveyStatus;
    SurveyTheme: SurveyTheme;
    Client: Client;
}

export class SurveyTheme {
    SurveyThemeId: number;
    Name: string;
}

export class Client {
    ClientId: number;
    Name: string;
}

export class FilterObject {
    SurveyStatusId: number;
    Client: string;
    Name: string;
    StartDate: Date;
    EndDate: Date;
}
